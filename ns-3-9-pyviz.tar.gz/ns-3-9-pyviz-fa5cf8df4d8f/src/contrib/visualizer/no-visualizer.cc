/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */

#include "ns3/simulator.h"
#include "visualizer.h"

namespace ns3 {

void
Visualizer::Run ()
{
  Simulator::Run ();
}

}
