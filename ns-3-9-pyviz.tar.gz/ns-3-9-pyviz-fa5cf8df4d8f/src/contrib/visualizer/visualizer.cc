/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#include <Python.h>

#include "visualizer.h"

namespace ns3 {

void
Visualizer::Run ()
{
  const char *argv[] = {"python", NULL};

  Py_Initialize();
  PySys_SetArgv(1, (char**) argv);
  PyRun_SimpleString(
                     "import visualizer\n"
                     "visualizer.start();\n"
                     );
  Py_Finalize();
}

}
