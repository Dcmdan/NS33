#! /usr/bin/env python

"""Compare that Wifi-Wired Bridging generates correct traces."""

arguments = ["--SendIp=0"]

